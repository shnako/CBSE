#!/bin/bash
java -Djava.net.preferIPv4Stack=true -jar mcom.jar