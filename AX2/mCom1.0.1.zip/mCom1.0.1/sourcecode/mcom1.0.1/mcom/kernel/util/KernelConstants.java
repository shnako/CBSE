package mcom.kernel.util;
/**
 * @Author Inah Omoronyia School of Computing Science, University of Glasgow 
 */

public class KernelConstants {
	public static final String BUNDLEDIR = "LocalBundleDir";
	public static final String BUNDLEDESCRIPTORDIR = "LocalBundleDescDir";
}
