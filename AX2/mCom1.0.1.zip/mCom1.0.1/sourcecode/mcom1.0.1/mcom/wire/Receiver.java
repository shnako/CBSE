package mcom.wire;

public interface Receiver {
	public void receiveMessage();
}
