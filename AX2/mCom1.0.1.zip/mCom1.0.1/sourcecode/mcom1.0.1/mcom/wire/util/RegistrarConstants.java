package mcom.wire.util;

public class RegistrarConstants {

	public static final String MULTICAST_ADDRESS_GROUP_IPV4 = "225.4.5.6";
	public static final String MULTICAST_ADDRESS_GROUP_IPV6 = "FF7E:230::1234";
	public static final int MULTICAST_PORT = 5000;
	public static final int DATAGRAM_LENGTH = 1024;


}
