package mcom.bundle.m;

import mcom.bundle.Contract;

public class TContract {

	public static void main(String[] args) {
		System.out.println(new Contract());		
	}

}
